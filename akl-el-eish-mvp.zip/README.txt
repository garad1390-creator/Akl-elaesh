أكل العيش – Akl El Eish | نسخة MVP أولية

محتويات المستودع:
- index.html: الصفحة الرئيسية
- style.css: التصميم المتجاوب
- app.js: التفاعلات التجريبية

طريقة النشر على GitHub Pages:
1) ارفع الملفات الثلاثة index.html وstyle.css وapp.js إلى جذر المستودع.
2) افتح Settings ثم Pages.
3) في Build and deployment اختر Deploy from a branch.
4) اختر Branch: main وFolder: /(root)، ثم Save.
5) انتظر حتى يظهر رابط GitHub Pages.

تنبيه: هذه نسخة واجهة MVP. قائمة المصادر روابط خارجية، وزر التحديث يحدث وقت فحص القائمة فقط. لا يوجد بعد جلب آلي للإعلانات أو حجز حقيقي أو دفع أو تتبع حي. يلزم ربط APIs/شراكات وخلفية آمنة قبل تشغيل هذه الوظائف.
